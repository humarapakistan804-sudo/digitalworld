Digital World - website files

1. Upload ALL of these to your GitHub repository (index.html, the assets folder and .nojekyll). Keep the folder structure.
2. On GitHub open Settings > Pages. Under Build and deployment choose "Deploy from a branch", pick main and "/ (root)", then Save.
3. After a minute your site opens at https://YOURNAME.github.io/REPOSITORY/

Note: this copy is a display copy. The Upload and Remove buttons only work on the Claude page, not on GitHub.
