DIGITAL WORLD - GitHub site with automatic YouTube videos

A) Website ko GitHub par lagana
 1. Is zip ki saari files GitHub repository mein upload karein (index.html, assets, scripts, .github, youtube-config.json, youtube.json, .nojekyll).
 2. Settings > Pages > Deploy from a branch > main > / (root) > Save.

B) YouTube se automatic videos
 1. Agar upload ke baad ".github" folder repository mein nazar na aaye: Add file > Create new file, naam mein likhein
        .github/workflows/youtube-sync.yml
    aur youtube-sync.yml ka matn paste karke Commit karein.
 2. Settings > Actions > General > Workflow permissions > "Read and write permissions" > Save.
 3. YouTube par har category ki ek playlist banayein (Shorts, Documentaries, Video Songs, Audio Songs, Dramas, Funny, Poetry).
    Naya video upload karte waqt usay sahi playlist mein daalein.
 4. Har playlist ka link youtube-config.json mein us category ke saamne "" ke andar paste karein, jaise
        "docs": "https://www.youtube.com/playlist?list=PLxxxxxxxx"
 5. Actions tab > "Sync YouTube videos" > Run workflow. Us ke baad ye har ghante khud chalta hai
    aur nayi videos website par us category mein aa jati hain.

Playlist ke baghair bhi naye videos aate hain: Short ho to Shorts mein, aur title mein drama/mp3/documentary jaisa lafz ho to us category mein (youtube-config.json ke "keywords").
